

<footer>

<div class="wrapper-copyright">
    <p class="copy">Copyright © <?php echo date("Y"); ?> <?php bloginfo( 'name' ); ?>. All Rights Reserved. </p>
    <p class="copy_powered"><span class="theme-credit">Powered by <a href="https://github.com/WailBouhadda/Template-Wordpress-Site-web-universitaire"  class="footer-logo"  style="text-decoration:  none; font-size: 16px;">Khalid Youssef Ghizlane</a></span></p>
</footer>
<?php wp_footer();?>