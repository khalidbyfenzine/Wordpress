# Template-Worpdress-Website-University 

## 1. Presentation:
<ul>
<li>University template using Wordpress</li>
</ul>

## 2. Main Technologies:

##### <a href="https://wordpress.org/download/">Wordpress</a>
##### <a href="https://www.php.net/">PHP</a>
##### <a href="https://getbootstrap.com/docs/4.5/getting-started/download/">BOOTSTRAP</a>

## 3. Some Captures about this project:

![screencapture-localhost-wordpress-2020-06-25-19_04_08](https://user-images.githubusercontent.com/48455549/85777254-5d8fec00-b719-11ea-8e91-2bff29f97907.png)


<hr>

![screencapture-localhost-wordpress-2020-06-25-19_09_26](https://user-images.githubusercontent.com/48455549/85777201-523cc080-b719-11ea-898a-a9e1eaf55d4f.png)

<br>

![screencapture-localhost-wordpress-2020-06-25-19_09_14](https://user-images.githubusercontent.com/48455549/85777224-57017480-b719-11ea-9123-e642f4fa5f68.png)
<hr>

## 4. Created by:

#### - <a href="https://github.com/khalidbyfenzine">Byfenzine Khalid</a>
#### - <a href="https://github.com/youssefalam">Al-Amghari Youssef</a>
#### - <a href="https://github.com/Ghizlanemardy">Mardy Ghizlane</a>


