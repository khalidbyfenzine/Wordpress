<?php get_header(); ?>
<div class="page_content_404">
    <div class="page_title">
        <h2>😞 Oops! Page not found. Please search again.</h2>
    </div>
    <div class="search-form-404">
        <?php get_search_form(); ?>
    </div>
</div>
<?php get_footer(); ?>

